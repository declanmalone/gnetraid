// function declarations

void bytewise_xor (unsigned char *dest, unsigned char *src, 
		   unsigned long bytes);
void aligned_word_xor(unsigned char *dest, unsigned char *src, 
		      unsigned long bytes);
